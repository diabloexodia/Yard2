from datetime import datetime
import pymysql
import boto3

e = 'bins.cwyonqvmmbi7.us-east-1.rds.amazonaws.com'
u = 'root'
p = 'rootroot'
d = 'BINS'
conn = pymysql.connect(host=e, user=u, passwd=p, database=d)

def lambda_handler(event, context):
    cur = conn.cursor()
    cur.execute(f"CREATE DATABASE IF NOT EXISTS {d}")
    cur.execute(f"USE {d}")

    table_name = "YARD_RECEIPTS"

    q = f"SELECT * FROM {table_name} ORDER BY created_at DESC LIMIT 1"
    cur.execute(q)
    row = cur.fetchone()

    if row is not None:
        column_names = [desc[0] for desc in cur.description]
        print("Newly Inserted Row in Table:", table_name)
        formatted_row = format_row(column_names, row)
        print(formatted_row)
    else:
        print("No Newly Inserted Rows in Table:", table_name)

    topic_arn = 'arn:aws:sns:us-east-1:082418964900:bins'

    send_sns_notification(topic_arn, formatted_row)

    conn.commit()
    cur.close()
    conn.close()

def format_row(column_names, row):
    formatted_row = "Newly Inserted Row in Table: yard_receipts\n"
    for i, value in enumerate(row):
        column_name = column_names[i]
        formatted_row += "{}: {}\n".format(column_name.upper(), value)
    return formatted_row

def send_sns_notification(topic_arn, formatted_row):
    sns_client = boto3.client('sns')
    sns_client.publish(TopicArn=topic_arn, Message=formatted_row)
